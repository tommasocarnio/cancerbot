from glob import glob
from telegram.ext import CommandHandler, MessageHandler, filters, Application, ContextTypes
from telegram import Update
import pandas as pd
import pickle
import re
import logging
import tensorflow as tf
from typing import Final
import tracemalloc
tracemalloc.start()
print(tf.__version__)
logging.basicConfig(level=logging.INFO)

data = {
    'raggio_medio':17.99,
    'forma_media':10.38,
    'perimetro_medio':122.8,
    'area_media':1001,
    'compattezza_media':0.2776,
    'concavità_media':0.3001,
    'punti_di_concavità_media':0.1471,
    'simmetria_media':0.2419,
    'dimensione_frattale_media':0.07871
}

TOKEN: Final = "6150592806:AAGcS_FR_RHQCRMc0AEsCT-iIhGI-gkTKW0"
BOT_USERNAME: Final = "@grancavalierebot"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Hai il cancro? Inserisci i dati e scoprilo!")

async def rispondi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.lower()
    if "help" in text:
        await update.message.reply_text("Inserire i 9 valori nel seguente formato:\nval1;val2;val3;...;val9")
    elif "try" in text:
        await update.message.reply_text("prova")
        #st = text.split(';')
        #data['raggio_medio'] = float(st[0])
        #data['forma_media'] = float(st[1])
        #data['perimetro_medio'] = float(st[2])
        #data['area_media'] = float(st[3])
        #data['compattezza_media'] = float(st[4])
        #data['concavità_media'] = float(st[5])
        #data['punti_di_concavità_media'] = float(st[6])
        #data['simmetria_media'] = float(st[7])
        #data['dimensione_frattale_media'] = float(st[8])        
        result = await predict(data)
        await update.message.reply_text(result)


async def predict(value=data):
    my_data = pd.DataFrame(data, 
                           index=[0], 
                           columns=['raggio_medio','forma_media','perimetro_medio','area_media','compattezza_media','concavità_media','punti_di_concavità_media','simmetria_media','dimensione_frattale_media'])
    model = pickle.load(open('model.pkl', 'rb'))
    results = model.predict(my_data)
    if results[0]>=0.5:
        return 'Hai il cancro'
    else:
        return 'Non hai il cancro'

async def error(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print(f'Update {Update} ha generato un errore')
if __name__ == '__main__':
    print('Starting bot...')
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(MessageHandler(filters.TEXT, rispondi))
    #app.add_error_handler(error)
    print('Polling bot')
    app.run_polling(poll_interval=3)
